# PROC105-V1-plantilla-proyecto
Plantilla del alumno.  
Video álbum.  
Imágenes a editar.  
  
### Texto en inglés: PRO-C105-Project-Images
